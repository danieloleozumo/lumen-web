import { useEffect, useState } from 'react';
import { useRouter } from '../router';
import { Logo } from './Logo';

export function Navigation() {
  const { currentRoute, navigate } = useRouter();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navClass = `fixed top-0 w-full z-50 transition-all duration-300 border-b ${
    isScrolled 
      ? 'bg-surface/95 shadow-sm border-outline-variant/30' 
      : 'bg-surface/90 border-outline-variant/30'
  } backdrop-blur-md`;

  return (
    <>
      <header className={navClass}>
        <div className="flex justify-between items-center px-margin-mobile md:px-margin-desktop h-24 max-w-container-max mx-auto">
          <button 
            onClick={() => navigate('home')}
            className="focus:outline-none"
          >
            <Logo variant="horizontal" />
          </button>
          <nav className="hidden md:flex gap-8 items-center font-label-caps text-label-caps">
            <button 
              onClick={() => navigate('home')}
              className={`${currentRoute === 'home' ? 'text-primary font-bold border-b-2 border-primary pb-1' : 'text-on-surface-variant font-medium hover:text-primary'} transition-colors duration-300`}
            >
              Inicio
            </button>
            <button 
              onClick={() => navigate('home')}
              className="text-on-surface-variant font-medium hover:text-primary transition-colors duration-300"
            >
              El Método
            </button>
            <button 
              onClick={() => navigate('entrenamientos')}
              className={`${currentRoute === 'entrenamientos' ? 'text-primary font-bold border-b-2 border-primary pb-1' : 'text-on-surface-variant font-medium hover:text-primary'} transition-colors duration-300`}
            >
              Programas
            </button>
            <button 
              onClick={() => navigate('centro')}
              className={`${currentRoute === 'centro' ? 'text-primary font-bold border-b-2 border-primary pb-1' : 'text-on-surface-variant font-medium hover:text-primary'} transition-colors duration-300`}
            >
              El Centro
            </button>
            <button 
              onClick={() => navigate('blog')}
              className={`${currentRoute === 'blog' ? 'text-primary font-bold border-b-2 border-primary pb-1' : 'text-on-surface-variant font-medium hover:text-primary'} transition-colors duration-300`}
            >
              Blog
            </button>
            <button 
              onClick={() => navigate('home')}
              className="text-on-surface-variant font-medium hover:text-primary transition-colors duration-300"
            >
              Equipo
            </button>
          </nav>
          <div className="hidden md:flex items-center gap-4">
            <button 
              onClick={() => navigate('empieza')}
              className="font-label-caps text-label-caps bg-primary text-on-primary px-6 py-3 rounded-full border border-primary-container hover:bg-surface-tint transition-colors duration-300 shadow-sm"
            >
              CÍRCULO FUNDADOR
            </button>
          </div>
          <button className="md:hidden text-primary p-2">
            <span className="material-symbols-outlined text-2xl">menu</span>
          </button>
        </div>
      </header>

      {/* Mobile Bottom Nav */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-center items-center px-margin-mobile py-4 md:hidden bg-surface/95 backdrop-blur-lg rounded-t-[2rem] border-t border-outline-variant/20 shadow-sm">
        <button 
          onClick={() => navigate('empieza')}
          className="flex flex-col items-center justify-center bg-primary text-on-primary rounded-full px-12 py-3 scale-95 duration-150 shadow-md w-full max-w-[250px]"
        >
          <span className="material-symbols-outlined fill-icon mb-1">bolt</span>
          <span className="font-label-caps text-label-caps text-xs">CÍRCULO FUNDADOR</span>
        </button>
      </nav>
    </>
  );
}
